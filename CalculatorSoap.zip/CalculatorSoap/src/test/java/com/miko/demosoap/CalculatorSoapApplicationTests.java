package com.miko.demosoap;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.miko.demosoap.arithmetic.ArithmeticInterface;
import com.miko.demosoap.arithmetic.OperatorAdd;
import com.miko.demosoap.arithmetic.OperatorMulti;
import com.miko.demosoap.arithmetic.OperatorSubstract;
import com.miko.demosoap.arithmetic.ResponseObject;
import com.miko.demosoap.res.ResultVariables;

@SpringBootTest
class CalculatorSoapApplicationTests {

	@Test
	void contextLoads() {
	}

	@Test
	public void testOperands() {
		ResponseObject rop = new ResponseObject(ResultVariables.RESULT_CODE_NULLPOINTER_ERROR, 0d);
		ArithmeticInterface operator = new OperatorAdd();
		operator.calculate(3d, null);
		ResponseObject ret = operator.getResp();
		assertEquals(ret, rop);
		
		rop = new ResponseObject(ResultVariables.RESULT_CODE_OK, 46d);
		operator.calculate(12d, 34d);
		ret = operator.getResp();
		assertEquals(ret, rop);
		
		rop = new ResponseObject(ResultVariables.RESULT_CODE_DIVIDE_BY_ZERO, 0d);
		operator = new OperatorSubstract();
		operator.calculate(5d, 0d);
		ret = operator.getResp();
		assertEquals(ret, rop);

		rop = new ResponseObject(ResultVariables.RESULT_CODE_NULLPOINTER_ERROR, 0d);
		operator = new OperatorSubstract();
		operator.calculate(3d, null);
		ret = operator.getResp();
		assertEquals(ret, rop);
		
		rop = new ResponseObject(ResultVariables.RESULT_CODE_POSITIVE_INFINITY, 0d);
		operator = new OperatorMulti();
		operator.calculate(Math.pow(32d, 1023), 6d);
		ret = operator.getResp();
		assertEquals(ret, rop);

		rop = new ResponseObject(ResultVariables.RESULT_CODE_NEGATIVE_INFINITY, 0d);
		operator = new OperatorMulti();
		operator.calculate(Math.pow(-32d, 1023), 6d);
		ret = operator.getResp();
		assertEquals(ret, rop);
		
	
	}
}
