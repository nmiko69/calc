package com.miko.demosoap.arithmetic;

import com.miko.demosoap.res.ResultVariables;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@EqualsAndHashCode
public class ResponseObject {
	
	double result;
	int resultCode;
	String resultString;
	
	public ResponseObject() {
		result = 0d;
		resultCode = ResultVariables.RESULT_CODE_OK;
		resultString = ResultVariables.RESULT_OK;
	}
	
	public ResponseObject(int resultCode, Double result) {
		this.result = result;
		
		setResultVariable(resultCode);
		
	}
	
	public void setResult(Double result) {
		
		if (result.equals(Double.POSITIVE_INFINITY)) {
			setResultVariable(ResultVariables.RESULT_CODE_POSITIVE_INFINITY);
			this.result = 0d;
		} else if (result.equals(Double.NEGATIVE_INFINITY)) {
			setResultVariable(ResultVariables.RESULT_CODE_NEGATIVE_INFINITY);
			this.result = 0d;
		} else {
			this.result = result;
		}
	}

	public void setResultVariable(int resultCode) {
		this.resultCode = resultCode;
		switch (resultCode) {
			case ResultVariables.RESULT_CODE_OK:
				resultString = ResultVariables.RESULT_OK;
				break;
			case ResultVariables.RESULT_CODE_DIVIDE_BY_ZERO:
				resultString = ResultVariables.RESULT_DIVIDE_BY_ZERO;
				break;
			case ResultVariables.RESULT_CODE_NULLPOINTER_ERROR:
				resultString = ResultVariables.RESULT_NULLPOINTER;
				break;
			case ResultVariables.RESULT_CODE_POSITIVE_INFINITY:
				resultString = ResultVariables.RESULT_POSITIVE_INFINITY;
				break;
			case ResultVariables.RESULT_CODE_NEGATIVE_INFINITY:
				resultString = ResultVariables.RESULT_NEGATIVE_INFINITY;
				break;
			default:
				resultString = ResultVariables.RESULT_UNKNOWN;
				break;
		}
	}

	

}
