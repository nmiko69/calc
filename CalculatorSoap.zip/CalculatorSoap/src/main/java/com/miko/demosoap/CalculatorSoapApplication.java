package com.miko.demosoap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.miko.demosoap.map.MappingResponse;
import com.miko.demosoap.map.MappingResponseImpl;

@SpringBootApplication
public class CalculatorSoapApplication {

	
	
	public static void main(String[] args) {
		SpringApplication.run(CalculatorSoapApplication.class, args);
	}
	
	@Bean
	MappingResponse mappingResponse() {
		return new MappingResponseImpl();
	}
}
