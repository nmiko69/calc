package com.miko.demosoap.arithmetic;

import org.springframework.stereotype.Component;

import com.miko.demosoap.res.ResultVariables;

@Component
public class OperatorSubstract extends AbstractOperator {

	@Override
	protected void processing(Double param1, Double param2) {	
		if (param2!=null && param2==0d) {
			resp.setResultVariable(ResultVariables.RESULT_CODE_DIVIDE_BY_ZERO);
			resp.setResult(0d);
		} else {
			resp.setResult(param1 / param2);
		}
	}
}
