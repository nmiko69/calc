package com.miko.demosoap.res;


public class ResultVariables {
	
	public static final int RESULT_CODE_OK = 200;
	public static final int RESULT_CODE_UNKNOWN_ERROR = 404;
	public static final int RESULT_CODE_DIVIDE_BY_ZERO = 422;
	public static final int RESULT_CODE_NULLPOINTER_ERROR = 406;
	public static final int RESULT_CODE_POSITIVE_INFINITY = 407;
	public static final int RESULT_CODE_NEGATIVE_INFINITY = 408;
	public static final int RESULT_CODE_ERROR_OPERANDUS = 409;
	
	
	public static final String RESULT_OK = "Operation successfully.";
	public static final String RESULT_UNKNOWN = "Unknown error in operand or parameters.";
	public static final String RESULT_DIVIDE_BY_ZERO = "Divide by zero error.";
	public static final String RESULT_NULLPOINTER = "Some parameters are NULL. Must be a numeric value.";
	public static final String RESULT_POSITIVE_INFINITY = "The result is too big.";
	public static final String RESULT_NEGATIVE_INFINITY = "The result is too small.";
	public static final String RESULT_UNKNOWN_OPERANDUS = "The operandus is unknown.";
	
	public static final String OPERANDUS_ADD = "a";
	public static final String OPERANDUS_MINUS = "d";
	public static final String OPERANDUS_MULTI = "s";
	public static final String OPERANDUS_SUBSTRACT = "o";
	
}
