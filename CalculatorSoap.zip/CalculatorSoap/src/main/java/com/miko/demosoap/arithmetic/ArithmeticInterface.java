package com.miko.demosoap.arithmetic;

public interface ArithmeticInterface {
	
	public void calculate(Double param1, Double param2); 
	
	

	
	default public void setResponseObject(int resultCode, ResponseObject resp) {
		resp.setResultVariable(resultCode);
		resp.setResult(0d);
	}
	
	public ResponseObject getResp();
	


}
