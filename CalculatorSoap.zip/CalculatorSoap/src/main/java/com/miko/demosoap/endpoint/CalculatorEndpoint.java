package com.miko.demosoap.endpoint;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import com.miko.demosoap.service.CalculatorService;
import com.miko.jobtry.calculator.CalculatorRequest;
import com.miko.jobtry.calculator.GetCalculatorResponse;

@Endpoint
public class CalculatorEndpoint {
	private static final String NAMESPACE_URI = "http://com/miko/jobtry/calculator";


	
	private CalculatorService service;
	
	@Autowired
	public CalculatorEndpoint(CalculatorService service) {
		this.service = service;
	}
	
	@PayloadRoot(namespace = NAMESPACE_URI, localPart = "calculatorRequest")
	@ResponsePayload
	public GetCalculatorResponse getResult(@RequestPayload CalculatorRequest request) {
		GetCalculatorResponse result = new GetCalculatorResponse();
		result.setCalculatorResponse(service.calculate(request));
		return result;
	}
	
	
	
	

}


