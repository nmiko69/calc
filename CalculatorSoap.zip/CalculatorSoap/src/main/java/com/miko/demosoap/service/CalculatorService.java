package com.miko.demosoap.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.miko.demosoap.arithmetic.ArithmeticInterface;
import com.miko.demosoap.arithmetic.OperatorAdd;
import com.miko.demosoap.arithmetic.OperatorMinus;
import com.miko.demosoap.arithmetic.OperatorMulti;
import com.miko.demosoap.arithmetic.OperatorSubstract;
import com.miko.demosoap.arithmetic.ResponseObject;
import com.miko.demosoap.map.MappingResponse;
import com.miko.demosoap.res.ResultVariables;
import com.miko.jobtry.calculator.CalculatorRequest;
import com.miko.jobtry.calculator.CalculatorResponse;

@Service
public class CalculatorService {
	@Autowired MappingResponse mapper;

	public CalculatorResponse calculate(CalculatorRequest request) {
		ArithmeticInterface operator = null;
		switch (request.getOperandus()) {
			case ResultVariables.OPERANDUS_ADD:
				operator = new OperatorAdd();
				break;
			case ResultVariables.OPERANDUS_MINUS:
				operator = new OperatorMinus();
				break;
			case ResultVariables.OPERANDUS_MULTI:
				operator = new OperatorMulti();
				break;
			case ResultVariables.OPERANDUS_SUBSTRACT:
				operator = new OperatorSubstract();
				break;
			default:
				break;
		}
		
		if (operator == null) {
			return mapper.daoToDto(new ResponseObject(ResultVariables.RESULT_CODE_ERROR_OPERANDUS, 0d));
		} else {
			operator.calculate(request.getParam1(), request.getParam2());
			return mapper.daoToDto(operator.getResp());
		}
	}
}
