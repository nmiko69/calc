package com.miko.demosoap.map;

import java.util.List;

import org.mapstruct.Mapper;

import com.miko.demosoap.arithmetic.ResponseObject;
import com.miko.jobtry.calculator.CalculatorResponse;

@Mapper
public interface MappingResponse {

	public CalculatorResponse daoToDto( ResponseObject dao);
	public List<CalculatorResponse> daoListToDtoList( List<ResponseObject> daoList );
	
}
