package com.miko.demosoap.arithmetic;

import org.springframework.stereotype.Component;

@Component
public class OperatorMulti extends AbstractOperator {

	@Override
	protected void processing(Double param1, Double param2) {	
		resp.setResult(param1 * param2);
	}
}
