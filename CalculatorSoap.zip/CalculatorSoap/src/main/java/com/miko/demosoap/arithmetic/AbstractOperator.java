package com.miko.demosoap.arithmetic;

import com.miko.demosoap.res.ResultVariables;

public abstract class AbstractOperator implements ArithmeticInterface {
	protected final ResponseObject resp = new ResponseObject();

	public void calculate(Double param1, Double param2) {
		resp.setResultVariable(ResultVariables.RESULT_CODE_OK);
		try {
			processing(param1, param2);
		} catch (NullPointerException ex) {
			setResponseObject(ResultVariables.RESULT_CODE_NULLPOINTER_ERROR, resp);
		} catch (ArithmeticException ex) {
			setResponseObject(ResultVariables.RESULT_CODE_DIVIDE_BY_ZERO, resp);
		} catch (RuntimeException ex) {
			setResponseObject(ResultVariables.RESULT_CODE_UNKNOWN_ERROR, resp);
		} 
	}
	
	protected void processing(Double param1, Double param2) {
	}

	public ResponseObject getResp() {
		return resp;
	}
	
	
}
